
// SmartCardInitDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"

// CSmartCardCleanDlg �Ի���
class CSmartCardCleanDlg : public CDialog
{
// ����
public:
	CSmartCardCleanDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_SMARTCARD_CLEAN_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

private:
	HANDLE m_RFHandle;
	UINT m_Timer;
	int RFState;	// 0-δ���ӣ�1-�����豸
	CString m_info;

	unsigned long CardSN;
	unsigned long ComID;

private:
	int StartRF();
	int InitCard(void);
	int ReadRF(int mode);
	int WriteRF(/*unsigned long csn, unsigned long comid*/);

	int ServerCardInit(const char* inNum, const char* outNum, long compNum);


	void AppendInfo(const TCHAR *info, ...);

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
	afx_msg void OnClose();
	afx_msg void OnDestroy();

	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CEdit m_CtrlInfo;
	//CComboBox m_CtrlCompList;
	// �⿨��
	//CEdit m_CtrlOutNum;
	afx_msg void OnEnKillfocusEditOutno();
	afx_msg void OnCbnSelchangeComplist();
	afx_msg void OnEnSetfocusInfo();
	afx_msg void OnCbnSelendcancelComplist();
	afx_msg void OnCbnSelendokComplist();
	afx_msg void OnCbnEditchangeComplist();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnEnChangeEditOutno();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
