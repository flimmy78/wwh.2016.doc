package com.epcentre.dao;

import com.epcentre.model.TblJpush;


public interface TblJpushDao {
	
	public TblJpush getByuserInfo(int jpushUserInfo);


}
