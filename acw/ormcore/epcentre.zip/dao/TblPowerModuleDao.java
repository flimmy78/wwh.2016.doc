package com.epcentre.dao;

import java.util.List;

import com.epcentre.model.TblPowerModule;

public interface TblPowerModuleDao {
	 
	public List<TblPowerModule> select(String SerialNo);
		
	public int insert(TblPowerModule info);
		
	public int update(TblPowerModule info);

}
