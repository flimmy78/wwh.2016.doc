package com.epcentre.dao;

import com.epcentre.model.TblEquipmentRepair;

/**
 * @Description: 充电记录操作DAO层接口Maper
 * @author songjf
 * @createTime：2015-4-10 下午01:58:51
 * @updator：
 * @updateTime：
 * @version：V1.0
 */
public interface EquipmentRepairDao {

	
	public int insert(TblEquipmentRepair info);


}
