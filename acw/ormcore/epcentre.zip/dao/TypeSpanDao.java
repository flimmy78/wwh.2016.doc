package com.epcentre.dao;

import java.util.List;

import com.epcentre.model.TblTypeSpan;


public interface TypeSpanDao {

	public List<TblTypeSpan> getAll();
	
	
}
