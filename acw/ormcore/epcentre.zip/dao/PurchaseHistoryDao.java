package com.epcentre.dao;


import com.epcentre.model.TblPurchaseHistory;

public interface PurchaseHistoryDao {
	
	public int insertPurchaseRecord(TblPurchaseHistory info);

}

