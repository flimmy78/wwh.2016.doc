package com.epcentre.dao;

import com.epcentre.model.TblUserThreshod;

public interface TblUserThreshodDao {
	
    
    public TblUserThreshod findUserThreshodInfo(int usrId);
	
}
