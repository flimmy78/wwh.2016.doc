package com.epcentre.dao;

import java.util.List;

public interface TblPartnerTimeDao {
	
	public List<?> getPartnersUpdateTime();
	
	public void insertPartnersUpdateTime();
	
	public void modifyPartnersUpdateTime();

}
