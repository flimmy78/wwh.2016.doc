package com.epcentre.model;

import java.util.Date;

public class TblConcentrator {
	
	private java.lang.Integer pkConcentratorID; // 主键
	
	private java.lang.Integer coctTypeSpanId; // 产品ID
	

	public java.lang.Integer getPkConcentratorID() {
		return pkConcentratorID;
	}

	public void setPkConcentratorID(java.lang.Integer pkConcentratorID) {
		this.pkConcentratorID = pkConcentratorID;
	}

	public java.lang.Integer getCoctTypeSpanId() {
		return coctTypeSpanId;
	}

	public void setCoctTypeSpanId(java.lang.Integer coctTypeSpanId) {
		this.coctTypeSpanId = coctTypeSpanId;
	}
	
	
	
}
