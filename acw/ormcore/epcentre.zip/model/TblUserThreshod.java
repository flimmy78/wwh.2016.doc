package com.epcentre.model;

public class TblUserThreshod {
	
	
	private Integer usrId;
	private Integer warnMoney;
	private String phone;//充电机编号
	private String customerPhone;
	public Integer getUsrId() {
		return usrId;
	}
	public void setUsrId(Integer usrId) {
		this.usrId = usrId;
	}
	public Integer getWarnMoney() {
		return warnMoney;
	}
	public void setWarnMoney(Integer warnMoney) {
		this.warnMoney = warnMoney;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	
	

}
