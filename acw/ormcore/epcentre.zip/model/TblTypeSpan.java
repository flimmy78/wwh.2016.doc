package com.epcentre.model;


public class TblTypeSpan {

	    private Integer typeSpanId;
		private String typeSpan; 
	

		public  TblTypeSpan()
		{
			typeSpanId=0;
			//typeSpan=new String("");
			
		}
		
		public Integer getTypeSpanId() {
			return typeSpanId;
		}

		public void setTypeSpanId(Integer typeSpanId) {
			this.typeSpanId = typeSpanId;
		}

		public String getTypeSpan() {
			return typeSpan;
		}

		public void setTypeSpan(String typeSpan) {
			this.typeSpan = typeSpan;
		}

	
}
