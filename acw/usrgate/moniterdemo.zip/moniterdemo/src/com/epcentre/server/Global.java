package com.epcentre.server;

import java.math.BigDecimal;

public class Global {
	public static java.math.BigDecimal DecTime1=new BigDecimal("10") ;//精确到分
	public static java.math.BigDecimal DecTime2=new BigDecimal("100") ;//精确到分
	public static java.math.BigDecimal DecTime3=new BigDecimal("1000") ;//精确到0.1分
	
	public static java.math.BigDecimal Dec1=new BigDecimal("0.1") ;//精确到分
	public static java.math.BigDecimal Dec2=new BigDecimal("0.01") ;//精确到分
	public static java.math.BigDecimal Dec3=new BigDecimal("0.001") ;//精确到0.1分

}
